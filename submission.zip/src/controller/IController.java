package controller;

/**
 * Represents the interface for a Controller.
 */
public interface IController {
  void collageProject() throws IllegalStateException;
}
